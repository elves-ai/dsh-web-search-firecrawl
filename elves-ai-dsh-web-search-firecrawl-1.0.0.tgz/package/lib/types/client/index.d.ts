/**
 * Client half of `@elves-ai/dsh-web-search-firecrawl`: contributes the
 * "Firecrawl" page to the DSH Settings shell.
 *
 * 0.2.0-rc.2 port: the old fenced `/firecrawl/api` route is gone. The shared
 * entry form is resolved in `apply` and handed to the section through the
 * slot inject face as the `form` prop — the component subscribes with
 * `useSyncExternalStore`, so the page renders as soon as the mirror answers
 * instead of stalling on "loading".
 */
import type { Context } from '@deepseek-ai/cordis';
import type { ConfigForm } from '@deepseek-ai/dsh-client-ui-settings/client';
/** Host plugin entry id owning this form (the profile row id). */
export declare const FIRECRAWL_ENTRY_ID = "web-search-firecrawl";
/** Required services before mounting. */
export declare const inject: string[];
/**
 * Register the Firecrawl settings section.
 * @param ctx - the browser plugin context.
 */
export declare function apply(ctx: Context & {
    slots: {
        register(options: object, component: unknown): () => void;
    };
    configForms: {
        get<T>(entryId: string): ConfigForm<T>;
        whileServed: (namespaces: readonly string[], register: () => () => void) => () => void;
    };
}): void;
