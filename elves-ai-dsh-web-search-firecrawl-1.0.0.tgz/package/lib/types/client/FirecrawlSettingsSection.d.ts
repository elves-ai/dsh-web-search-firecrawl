/**
 * The "Firecrawl" settings page contributed to the DSH Settings shell.
 *
 * 0.2.0-rc.2 port: the form is resolved in `apply` and handed in through the
 * slot inject face (`useSettings` selector hook + `mutateSettings`), the same
 * pattern as the approved `dsh-web-search-enhanced` plugin. The API key is
 * write-only in the wire direction: the host schema marks it `role('secret')`,
 * so this page never receives the literal — it shows whether a key is
 * configured, accepts a replacement (blank = keep the current key), and
 * offers an explicit clear button. All commits apply live.
 */
import type { ConfigForm } from '@deepseek-ai/dsh-client-ui-settings/client';
import type { PropsRuntime } from '@deepseek-ai/dsh-client-ui-slots';
/** Props the settings shell binds for this section (plus the inject face). */
export type FirecrawlSettingsSectionProps = PropsRuntime<'settings.section'> & {
    /** Shared entry form handed in by `apply` through the slot inject face. */
    form?: ConfigForm<Record<string, unknown>>;
};
/**
 * Render the Firecrawl settings page.
 * @param props - the runtime share of a `settings.section` entry plus the form face.
 * @returns the section element tree.
 */
export declare function FirecrawlSettingsSection(props: FirecrawlSettingsSectionProps): import("react").JSX.Element;
